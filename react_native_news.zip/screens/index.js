import HomeScreen from "./HomeScreen";
import NewsScreen from "./NewsScreen";
import NotificationsScreen from "./NotificationsScreen";
import SettingsScreen from "./SettingsScreen";
import DetailScreen from "./DetailScreen";
export { HomeScreen, NewsScreen, NotificationsScreen, SettingsScreen, DetailScreen };