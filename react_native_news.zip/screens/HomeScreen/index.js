import React, { useState, useEffect } from "react";
import Moment from "moment";
import { useNavigation } from '@react-navigation/native';
import {
  View,
  SafeAreaView,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  useWindowDimensions,
  ScrollView
} from "react-native";
// Styles
import styles from "./styles";
// Data
import { BLOGS, CATEGORIES } from "./data";
const Index = () => {
  const [isLoading, setLoading] = useState(false);
  const [blogs, setBlogs] = useState([]);
  const [categories, setCategories] = useState([]);
  useEffect(() => {
    setBlogs(BLOGS);
    setCategories(CATEGORIES);
  }, []);
  const navigation = useNavigation();
  const { width } = useWindowDimensions();
  return (
    <SafeAreaView style={{ paddingLeft: 10, paddingRight: 10 }}>
      <View
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "row",
          marginBottom: 10,
        }}
      >
        <ScrollView
          horizontal
          accessibilityIgnoresInvertColors={false}
          style={{ marginTop: 10 }}
        >
          {CATEGORIES.map((item, index) =>
            <View key={index}>
              <TouchableOpacity style={styles.button} onPress={() => {
                navigation.navigate('DetailScreen', {
                  id: item.id,
                  name: item.name
                });
              }}>
                <Text style={styles.white}>{item.name}</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </View>
      {isLoading ? (
        <ActivityIndicator size="large" color="#ff0000" />
      ) : (
        <View>
          <FlatList
            data={blogs}
            keyExtractor={({ id }) => id}
            renderItem={({ item }) => (
              <View
                style={{
                  display: "flex",
                  flexDirection: "row",
                  marginBottom: 10,
                }}
              >
                <View>
                  <Image
                    source={require("../../assets/blogs/19.jpg")}
                    style={{ width: 100, height: 100, borderRadius: 5 }}
                  />
                </View>
                <View style={{ paddingLeft: 10 }}>
                  <Text
                    style={{ fontWeight: "bold", fontSize: 15, color: "#000" }}
                  >
                    {item.title}
                  </Text>
                  <Text
                    style={{
                      fontStyle: "normal",
                      fontSize: 9,
                      color: "#ff0000",
                      marginTop: 3,
                    }}
                  >
                    <Text style={{ color: "#363636" }}>Post date: </Text>
                    {Moment(item.publishedAt).format("dddd MM, YYYY")}
                  </Text>
                  <Text
                    style={{ fontSize: 12, color: "#363636", marginTop: 3 }}
                  >
                    {item.description}
                  </Text>
                </View>
              </View>
            )}
          />
        </View>
      )}
    </SafeAreaView>
  );
};
export default Index;
