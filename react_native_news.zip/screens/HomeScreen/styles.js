import React from "react";
import { StyleSheet, Dimensions } from "react-native";
const { width, height } = Dimensions.get("window");
const styles = StyleSheet.create({
    wrap: {
        width: width,
        height: width * 0.6,
    },
    image: {
        width: height,
        height: 300,
    },
    paging: {
        flexDirection: "row",
        position: "absolute",
        bottom: 0,
        alignSelf: "center",
    },
    pagingText: {
        color: "#888",
        margin: 3,
    },
    button: {
        borderRadius: 5,
        backgroundColor: "#ff0000",
        padding: 10,
        margin: 3,
    },
    white: {
        color: "#fff",
        fontWeight: "bold",
    },
});
export default styles;