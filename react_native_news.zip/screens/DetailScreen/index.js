import React, { useState, useLayoutEffect } from "react";
import { Text, View } from "react-native";
const Index = ({ route, navigation }) => {
    const { params } = route;
    const [value] = useState(params.name);
    useLayoutEffect(() => {
        navigation.setOptions({
            title: value === '' ? 'No title' : value,
        });
    }, [navigation, value]);
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Detail Screen!</Text>
        </View>
    );
}
export default Index;